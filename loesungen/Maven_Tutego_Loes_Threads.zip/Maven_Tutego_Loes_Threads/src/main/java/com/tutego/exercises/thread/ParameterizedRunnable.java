package com.tutego.exercises.thread;

public class ParameterizedRunnable {
  static
  //tag::solution-1[]
  class PrintingRunnable implements Runnable {
    private final String text;
    private final int repetitions;
    private int result;

    PrintingRunnable( String text, int repetitions ) {
      this.text = text;
      this.repetitions = repetitions;
    }

    @Override public void run() {
      for ( int i = 0; i < repetitions; i++ )
        System.out.printf( "%s; %s%n", text, Thread.currentThread() );
      result = 2;//(int) (Math.random() * 10);
    }

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}
    
    
  }
  //end::solution-1[]

  //tag::solution-2[]
  public static Runnable getPrintingRunnable( String text, int repetitions ) {
    return () -> {
      for ( int i = 0; i < repetitions; i++ )
        System.out.printf( "%s; %s%n", text, Thread.currentThread() );

    };
    
  
  }
  
  
  //end::solution-2[]

  public static void main( String[] args ) {
    PrintingRunnable r1 = new PrintingRunnable( "Wink", 30 );
    Thread t1 = new Thread(r1);
    t1.start();
//    try {
//		t1.join();
//	} catch (InterruptedException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
    System.out.println(r1.getResult());
    Runnable r2 = getPrintingRunnable( "Wave flag", 50 );
  }
}
