Loesungen (auch alternative) zu der Important Gossip Aufgabe
von den Tutego Aufgaben zu Maps.