package sk.train.ma_verwaltung_strategy;

import java.math.BigDecimal;

public interface Gehaltsmodell {
	public abstract BigDecimal getGehalt();
}
