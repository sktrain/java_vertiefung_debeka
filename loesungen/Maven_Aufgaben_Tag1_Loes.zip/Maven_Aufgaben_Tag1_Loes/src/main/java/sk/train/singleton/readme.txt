Der Test via main-Methode ist hier einfacher, da JUnit aufgrund seiner Test-Initalisierung 
uns hier ein paar Steine in den Weg legt.
(siehe den entsprechenden Junit-Test)