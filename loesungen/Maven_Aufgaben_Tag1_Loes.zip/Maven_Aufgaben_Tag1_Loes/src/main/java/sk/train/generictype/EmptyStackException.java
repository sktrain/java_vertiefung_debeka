package sk.train.generictype;

@SuppressWarnings("serial")
public class EmptyStackException extends IllegalStateException {

	public EmptyStackException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
