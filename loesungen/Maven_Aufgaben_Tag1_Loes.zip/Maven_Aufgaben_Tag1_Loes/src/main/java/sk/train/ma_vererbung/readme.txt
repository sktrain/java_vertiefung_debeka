Basisversion der Mitarbeiterklasse, sauberer Vererbung und 
abstrakter Elternklasse für die abstrakte getGehalt-Methode.
