package sk.train.ma_verwaltung_strategy;

public enum Geschlecht { W, M, D

}
