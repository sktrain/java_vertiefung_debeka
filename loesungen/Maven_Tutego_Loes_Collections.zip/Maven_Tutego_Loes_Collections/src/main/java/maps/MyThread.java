package maps;

public class MyThread implements Runnable {
	private int input;
	private int result;	
	
	public MyThread(int input) {
		super();
		this.input = input;
	}

	public void run() {
		
		for (int i = 1; i <= 1000; i++) {
			System.out.println(Thread.currentThread().getName() + " : " + i);
			input = input + i;
		}
	}

	public int getResult() {
		result=input;
		return result;
	}



	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread());
		MyThread r1 = new MyThread(10);
		Thread t1 = new Thread(r1);
		//Thread t2 = new Thread(new MyThread());
		t1.start();
		t1.join();
		System.out.println(r1.getResult());
		//t2.start();
	}
}