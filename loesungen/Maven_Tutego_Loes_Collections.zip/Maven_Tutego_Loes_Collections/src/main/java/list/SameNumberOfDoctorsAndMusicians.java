package list;

import java.util.Arrays;
import java.util.List;

public class SameNumberOfDoctorsAndMusicians {
  static class CrewMember {
    enum Profession { CAPTAIN, NAVIGATOR, CARPENTER, DOCTOR, MUSICIAN, COOK }

    String name;
    Profession profession;

    CrewMember( String name, Profession profession ) {
      this.name = name;
      this.profession = profession;
    }
  }

  //tag::solution-switch[]
  public static boolean areSameNumberOfDoctorsAndMusicians( List<CrewMember> crewMembers ) {
    int weight = 0;
    for ( CrewMember member : crewMembers ) {
      switch ( member.profession ) {
        case DOCTOR:   weight++; break;
        case MUSICIAN: weight--; break;
      }
    }
    return weight == 0;
  }
  //end::solution-switch[]

  /*
  public static boolean areSameNumberOfDoctorsAndMusiciansSwitchExpr( List<CrewMember> crewMembers ) {
    int weight = 0;
    //tag::solution-switch-expr[]
    for ( CrewMember member : crewMembers ) {
      weight += switch ( member.profession ) {
        case DOCTOR -> +1;
        case MUSICIAN -> -1;
        default -> 0;
      };
    }
    //end::solution-switch-expr[]
    return weight == 0;
  }
  */

  public static boolean areSameNumberOfDoctorsAndMusicians2( List<CrewMember> crewMembers ) {
    //tag::solution-b[]
    int result = 0;
    for ( CrewMember member : crewMembers ) {
      //                                                          CAPTAIN -+
      //                                                      NAVIGATOR -+ |
      //                                                    CARPENTER -+ | |
      //                                                     DOCTOR -+ | | |
      //                                                 MUSICIAN -+ | | | |
      //                                                           v v v v v
      int zeroOrOneOrTwo = ((1 << member.profession.ordinal()) & 0b1_1_0_0_0) / 8;
      int minusOneOrZeroOrPlusOne = (zeroOrOneOrTwo / 2) - (zeroOrOneOrTwo & 1);
      result += minusOneOrZeroOrPlusOne;
    }
    return result == 0;
    //end::solution-b[]
  }

  public static void main( String[] args ) {
    //tag::example[]
    CrewMember captain   = new CrewMember( "CiaoCiao", CrewMember.Profession.CAPTAIN );
    CrewMember doctor1   = new CrewMember( "Dr. Bob", CrewMember.Profession.DOCTOR );
    CrewMember doctor2   = new CrewMember( "The Witch Doctor", CrewMember.Profession.DOCTOR );
    CrewMember musician1 = new CrewMember( "Mahna Mahna", CrewMember.Profession.MUSICIAN );
    CrewMember musician2 = new CrewMember( "Rowlf", CrewMember.Profession.MUSICIAN );

    List<CrewMember> crew1 = Arrays.asList( doctor1, musician1 );
    System.out.println( areSameNumberOfDoctorsAndMusicians( crew1 ) ); // true

    List<CrewMember> crew2 = Arrays.asList( doctor1, musician1, musician2, captain );
    System.out.println( areSameNumberOfDoctorsAndMusicians( crew2 ) ); // false

    List<CrewMember> crew3 = Arrays.asList( doctor1, musician1, musician2, captain, doctor2  );
    System.out.println( areSameNumberOfDoctorsAndMusicians( crew3 ) ); // true
    //end::example[]

    System.out.println( areSameNumberOfDoctorsAndMusicians2( crew1 ) ); // true
    System.out.println( areSameNumberOfDoctorsAndMusicians2( crew2 ) ); // false
    System.out.println( areSameNumberOfDoctorsAndMusicians2( crew3 ) ); // true
  }
}
