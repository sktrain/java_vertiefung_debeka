Umsetzung des Observer/Observable-Pattern

Eigene Verwaltung der Observer auf der Observable-Seite.
Damit das vern�nftig getestet werden kann, sollten schon ein paar Dinge abfragbar sein!