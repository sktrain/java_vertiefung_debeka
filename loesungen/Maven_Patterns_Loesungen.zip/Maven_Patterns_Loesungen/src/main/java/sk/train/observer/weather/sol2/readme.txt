Umsetzung des Observer/Observable-Pattern

 
Nutzung der Observable-Klasse zur Verwaltung der Observer und des Interface Observer aus java.util.