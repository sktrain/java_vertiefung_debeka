package sk.train.observer.weather.sol2;

public interface DisplayElement {
	public void display();
}
