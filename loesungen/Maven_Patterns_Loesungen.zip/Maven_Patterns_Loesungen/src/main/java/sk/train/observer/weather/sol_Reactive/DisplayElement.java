package sk.train.observer.weather.sol_Reactive;

public interface DisplayElement {
	public void display();
}
