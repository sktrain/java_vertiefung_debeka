package sk.train.generictype;

public class EmptyStackException extends IllegalStateException {
}
