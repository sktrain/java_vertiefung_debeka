Basisversion der Mitarbeiterklasse und Kindklasse ArbeiterVar1 bzw ArbeiterVar2 jeweils mit Vererbungsproblem.
Wie kann dies behoben werden und jeder Mitarbeiter mittels getGehalt seinen korrekten Gehaltswert liefern?
(Hinweis: "abstrakte Elternklasse")