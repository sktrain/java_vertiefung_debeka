Die Stack-Klasse soll als generische Version angeboten werden. 
Das Memory Leak sollte geschlossen werden.
Optional: statt mit der Verdopplungsstrategie k�nnte flexibler via Funktionsbaustein gearbeitet werden. (Lambda)
Es sollten auch Methoden pushAll und popAll f�r viele Elemente vorhanden sein (liefern/erwarten Collections)