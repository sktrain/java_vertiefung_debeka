Scheinbar einfach: Kindklasse von HashSet, die jeweils beim Hinzuf�gen die Anzahl der hinzugef�gten Elemente mitz�hlt 
und in einem Z�hler verwaltet, der abgefragt werden kann. (Der Einfachheit halber nur Mitz�hlen beim Hinzuf�gen).

Optional: statt Test via main-Methode besser mit JUnit.
