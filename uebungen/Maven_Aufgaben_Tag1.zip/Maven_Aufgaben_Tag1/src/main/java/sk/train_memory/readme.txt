Alle 3 Beispielsklassen (Person, Stack, Sum), haben ein Speicherproblem (EmptyStackException ist nur Hilfsklasse)
Die Klasse Person_old, die "java.util.Date" benutzt und nat�rlich auch das Problem hat, ist nur zur Demo hier!

Optional: Testen via JUnit