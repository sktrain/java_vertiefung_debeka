package Aufgaben_3_9;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Aufgabe_1 {

	public static void main(String[] args) {

		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		final List<String> names = Arrays.asList(namesArray);
		
		final Stream<String> streamFromArray = null;	// ... TODO ...
		final Stream<String> streamFromList = null;	// ... TODO ...
		final Stream<String> streamFromValues = null;	// ... TODO ...
		
		
		final Stream<String> filtered = null;	// ... TODO ...
		final Stream<String> mapped = null;	// ... TODO ...

	}

}
