Es soll eine Variante unter Nutzung des Builder Patterns bereit gestellt werden, 
m�glichst ein immutable Objekt.
(Beispiel aus "Effective Java", Joshua Bloch, Second Edition)