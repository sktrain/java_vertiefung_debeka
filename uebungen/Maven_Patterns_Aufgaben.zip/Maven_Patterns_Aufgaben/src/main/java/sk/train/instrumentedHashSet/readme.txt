Anwendung des Decorator Patterns um zu einer verbesserten Variante zu kommen


