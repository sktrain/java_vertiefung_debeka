Die vorhandene Singleton-Implementierung soll durch eine Umsetzung auf
Basis eines Enums ersetzt werden.