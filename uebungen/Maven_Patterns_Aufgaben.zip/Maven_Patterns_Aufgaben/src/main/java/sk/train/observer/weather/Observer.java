package sk.train.observer.weather;

public interface Observer {
	public void update(WeatherData data);
}
