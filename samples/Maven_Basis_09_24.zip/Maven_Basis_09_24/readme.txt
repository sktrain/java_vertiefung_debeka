Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom
		September 2024
		+ Jupiter-Dependencies
(erstellt auf Basis des Apache Maven Simple Archetype)